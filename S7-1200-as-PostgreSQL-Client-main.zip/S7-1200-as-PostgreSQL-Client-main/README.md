# S7-1200-as-PostgreSQL-Client
This project shows the S7-1200 connects to PostgreSQL Server and send simple SELECT request.
IDE: TIA Portal v.16
PostgreSQL v.14
